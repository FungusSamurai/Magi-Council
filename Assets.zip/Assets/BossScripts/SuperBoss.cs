﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public class SuperBoss : MonoBehaviour
{
    public GameObject bossShotLeft;
    public GameObject bossShotRight;
    public GameObject bossShotFront;
    public GameObject bossShotStrafe;
    public GameObject shotBox;

    private Vector2 screenSize;

    //    private GameObject player;
    //    private BulletManager playerManager;

    private List<int> weakness;

    public int maxHealth;
    public int health;
    public int attackRangeStart;
    public int attackRangeEnd;
    public int attackLength;

    // ERIC'S MODS

    public Vector3 initPos; // ERIC'S MOD


    // Use this for initialization
    void Awake()
    {
        
        weakness = new List<int>(4) { 3, 4, 5, 6, 7 };
        shotBox = GameObject.Find("EnemyShotSpawn");
//        player = GameObject.Find("Player");
//        playerManager = player.GetComponent<BulletManager>();

        screenSize = GetMainGameViewSize();
    }

    // Update is called once per frame
    void Update()
    { 
        if (Input.GetKeyDown(KeyCode.P))
            StartCoroutine(Attack());

        // ERIC'S MOD:
        initPos = new Vector3(shotBox.transform.position.x, shotBox.transform.position.y + 0.2f, shotBox.transform.position.z); // ERIC'S MOD
    }

    public void GetBullets(string nameL, string nameR, string nameF, string nameS)
    {
        bossShotLeft = GameObject.Find(nameL);
        bossShotRight = GameObject.Find(nameR);
        bossShotFront = GameObject.Find(nameF);
        bossShotStrafe = GameObject.Find(nameS);
    }

    IEnumerator Attack()
    {
        for (int i = 0; i < attackLength; i++)
        {
            yield return new WaitForSeconds(2.0f);
            RandomAttack(Random.Range(attackRangeStart, attackRangeEnd));
        }
    }

    public void RandomAttack(int value)
    {
        Debug.Log(value);

        if (value == 1)
        {
            LeftAttack(bossShotLeft);
        }

        if (value == 2)
        {
            RightAttack(bossShotRight);
        }

        if (value == 3)
        {
            ForwardAttack(bossShotFront);
        }

        if (value == 4)
        {
            StrafeAttack(bossShotStrafe);
            
        }
    }

    void LeftAttack(GameObject bullet)
    {
        //Instantiate(bullet, shotBox.transform.position, shotBox.transform.rotation);
        Instantiate(bullet, initPos, shotBox.transform.rotation);
        Debug.Log("Left Fired");
    }

    void RightAttack(GameObject bullet)
    {
        //Instantiate(bullet, shotBox.transform.position, shotBox.transform.rotation);
        Instantiate(bullet, initPos, shotBox.transform.rotation);
        Debug.Log("Right Fired");
    }

    void ForwardAttack(GameObject bullet)
    {
        //Instantiate(bullet, shotBox.transform.position, shotBox.transform.rotation);
        Instantiate(bullet, initPos, shotBox.transform.rotation);
        Debug.Log("Forward Fired");
    }

    void StrafeAttack(GameObject bullet)
    {
        //Instantiate(bullet, shotBox.transform.position, shotBox.transform.rotation);
        Instantiate(bullet, initPos, shotBox.transform.rotation);
        Debug.Log("Strafe Fired");
    }

    void AddWeakness(int shotType)
    {
        weakness.Add((int)shotType);
        Debug.Log("New Weaknesses are: " + weakness);
    }

    void TakeDamage(int shotData)
    {
        foreach (int w in weakness)
        {
            if (shotData == w)
            {
                health -= 1;
                Debug.Log("Boss has been hurt! " + health);
            }
        }

        if (health == 0)
        {
            //death animation
        }
    }

    public int Health
    {
        get { return health; }
        set { health = value; }
    }

    public int MaxHealth
    {
        get { return maxHealth; }
        set { maxHealth = value; }
    }

    public int AttackLength
    {
        get { return attackLength; }
        set { attackLength = value; }
    }

    void OnCollisionEnter(Collision col)
    {
        Debug.Log("Hit");
        if (col.collider.tag == "PlayerShot")
        {
            Debug.Log(col.collider.name);
            DataCapsule capsule = col.collider.GetComponent<DataCapsule>();
            int data = capsule.Type;
            Debug.Log("Data: " + data);
            TakeDamage(data);
            Destroy(col.gameObject);
        }
    }

    void OnGUI()
    {
        GUI.backgroundColor = Color.red;
        
        //GUI.HorizontalScrollbar(new Rect((Screen.width / 2 - 200), (Screen.height / 2 + 250), 400, 40), 0, health, 0, maxHealth);
        GUI.HorizontalScrollbar(new Rect((screenSize.x /2 - 200), (screenSize.y / 2 + 250), 400, 40), 0, health, 0, maxHealth);
    }

    public static Vector2 GetMainGameViewSize()
    {
        System.Type T = System.Type.GetType("UnityEditor.GameView,UnityEditor");
        System.Reflection.MethodInfo GetSizeOfMainGameView = T.GetMethod("GetSizeOfMainGameView", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);
        System.Object Res = GetSizeOfMainGameView.Invoke(null, null);
        return (Vector2)Res;
    }

}
