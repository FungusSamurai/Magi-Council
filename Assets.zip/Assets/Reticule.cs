﻿using UnityEngine;
using System.Collections;

public class Reticule : MonoBehaviour {
    private GameObject player;
    private Vector3 target;

	// Use this for initialization
	void Start () {
        player = GameObject.FindWithTag("Player");
       
        
	
	}
	
	// Update is called once per frame
	void Update () {
        transform.LookAt(player.transform.position);
        if (target == null)
        {
            transform.position = player.transform.position;
        }
        else
        {
            target = Player.getCurrentTarget();
            transform.position = target;
        }
	
	}
}
