﻿using UnityEngine;
using System.Collections;

public class Shot4Behavior : MonoBehaviour
{

    public int vel;
    private Rigidbody self;
    private GameObject target;


    // Use this for initialization
    void Awake()
    {
        vel = 10;
        self = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        self.velocity = transform.TransformDirection(new Vector3(0, 0, vel));

        Destroy(self.gameObject, 2);

    }

    void OnTriggerEnter()
    {
        //if (target.tag == "Target")
        //{
        Destroy(self.gameObject);
        //}
    }
}
