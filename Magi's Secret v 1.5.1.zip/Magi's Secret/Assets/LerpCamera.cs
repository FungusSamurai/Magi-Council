﻿using UnityEngine;
using System.Collections;

public class LerpCamera : MonoBehaviour
{
    public GameObject target;
    private GameObject player;
    public GameObject enemy;

    float timeStartedLerping;

    private Vector3 startPosition;
    private Vector3 endPosition;

    public float timeForLerp;

    public float camDistanceX;
    public float camDistanceY;
    public float camDistanceZ;


    private Vector3 halfPoint;
    private Transform cam;

    // Use this for initialization
    void Awake()
    {
        cam = Camera.main.transform; //GetComponent<Camera>();
        player = GameObject.FindWithTag("Player");
        timeForLerp = .19154f;

    }

    // Update is called once per frame
    void Update()
    {
        Vector3 playaPosition = cam.InverseTransformPoint(player.transform.position);
        halfPoint = (player.transform.position - enemy.transform.position) * 0.5f + enemy.transform.position;
        transform.LookAt(halfPoint);
        lerpTest(playaPosition);



    }

    void lerpTest(Vector3 pPos)
    {

        startPosition.x = pPos.x;
        startPosition.y = pPos.y;
        startPosition.z = pPos.z;

        endPosition.x = pPos.x + camDistanceX;
        endPosition.y = pPos.y + camDistanceY;
        endPosition.z = pPos.z + camDistanceZ;


        Debug.Log("POS X: " + endPosition.x);
        Debug.Log("POS Y: " + endPosition.y);
    }

    void FixedUpdate()
    {

        transform.Translate(endPosition * Time.deltaTime * 3.5f, Space.Self);

    }
}
