﻿using UnityEngine;
using System.Collections;

public class DataCapsule : MonoBehaviour {

    private GameObject player;
    private BulletManager playerManager;
    private int type;

    // Use this for initialization
    void Start () {

        type = -1;
        player = GameObject.Find("Player");
        playerManager = player.GetComponent<BulletManager>();
        GetShot();

    }
	
	// Update is called once per frame
	void Update () {

        Debug.Log("Type: " + Type);

    }


    void GetShot()
    {
        if (gameObject.tag == "PlayerShot")
        {
            Type = playerManager.ToCapsule;
            playerManager.ToCapsule = -1;
            Debug.Log("Player Shot!:" + Type);
        }

        if (gameObject.tag == "ShotX")
        {
            Type = 0;
        }

        if (gameObject.tag == "ShotY")
        {
            Type = 1;
        }

        if (gameObject.tag == "ShotZ")
        {
            Type = 2;
        }
    }



 //   void SetType(int t)
   // {
     //   Type = t;
    //}

    public int Type
    {
        get { return type; }
        set { type = value; }
    }
}
