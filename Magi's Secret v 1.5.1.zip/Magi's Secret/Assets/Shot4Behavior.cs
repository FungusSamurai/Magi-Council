﻿using UnityEngine;
using System.Collections;

public class Shot4Behavior : MonoBehaviour
{

    public float vel;
    private Rigidbody self;
    private GameObject target;

    Vector3 targetPosition;

    private bool moveToTarget;

    // Use this for initialization
    void Awake()
    {
        target = GameObject.FindWithTag("Player");
        targetPosition = new Vector3(target.transform.position.x, target.transform.position.y, target.transform.position.z);
        vel = 11f;
        //transform.Rotate(targetPosition);
        //transform.localEulerAngles = new Vector3(targetPosition.x, targetPosition.y,targetPosition.z);

        self = GetComponent<Rigidbody>();
        StartCoroutine(attackPattern());


    }

    IEnumerator attackPattern()
    {
        yield return new WaitForSeconds(.5f);
        transform.LookAt(targetPosition);
        //self.velocity = transform.TransformDirection(new Vector3(0.3f, 0, vel));
        //self.velocity = transform.TransformDirection(new Vector3(target.transform.position.x - 0.3f, target.transform.position.y, vel));
        moveToTarget = true;


    }

    // Update is called once per frame
    void Update()
    {
        //self.velocity = transform.TransformDirection(new Vector3(0.8f, 3, vel));
        if (moveToTarget)
        {
            //transform.position = Vector3.MoveTowards(transform.position, targetPosition, vel);
            transform.position += transform.forward * Time.deltaTime * vel;
        }
        Destroy(self.gameObject, 2);

    }

    /*
    void OnTriggerEnter()
    {
        //if (target.tag == "Target")
        //{
        //Destroy(self.gameObject);
        //}
    }
     * */
}
