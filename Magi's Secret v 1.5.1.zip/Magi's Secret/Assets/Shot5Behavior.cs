﻿using UnityEngine;
using System.Collections;

public class Shot5Behavior : MonoBehaviour
{

    public int vel;
    private Rigidbody self;
    private GameObject target;


    // Use this for initialization
    void Awake()
    {
        vel = 10;
        self = GetComponent<Rigidbody>();
        self.velocity = transform.TransformDirection(new Vector3(0, -3, vel));
    }

    // Update is called once per frame
    void Update()
    {
        Destroy(self.gameObject, 2);

    }

    void OnTriggerEnter()
    {
        //if (target.tag == "Target")
        //{
        Destroy(self.gameObject);
        //}
    }
}
