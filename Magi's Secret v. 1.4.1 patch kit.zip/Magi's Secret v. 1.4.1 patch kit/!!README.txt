- Go to shot2, shot3, and shot4, and check the Freeze Position and Rotation for X,Y, and Z coordinate.

- Replace scripts for each shot with provided scripts.

- Unchild Camera from Player character and disable Autocam script.

- Add provided LerpCam script to the MAIN CAMERA, NOT MULTIPURPOSE CAMERA RIG

- In LerpCamera's component parameters, set Target to the Player object and Enemy to Enemy.

- When playing game, modify Cam Distance X, Y, and Z to your preferences in the component parameters.