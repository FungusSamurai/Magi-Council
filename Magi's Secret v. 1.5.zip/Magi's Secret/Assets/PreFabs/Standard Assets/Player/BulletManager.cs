﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public enum ShotType
{ x, y, z, xx, yy, zz, xy, xz, yz, xxx, xxy, xxz, yyy, yyx, yyz, zzz, zzx, zzy, xyz }

public class BulletManager : MonoBehaviour
{
    public GameObject player;
    public GameObject playerBullet;
    public GameObject shotBox;

    private static int playerShot;
    private static int toCapsule;
    private static int fromCapsule;

    //    private int enemyShot;
    private int[] ownedShots;
    private int loadCount;
    //    private List<string> shotType;
    private int slot1, slot2, slot3;
    private int xCount, yCount, zCount;
    //    private int load1, load2, load3;

    // Use this for initialization
    void Start()
    {
        player = GameObject.FindWithTag("Player");

        slot1 = -1; slot2 = -1; slot3 = -1;
        xCount = 0; yCount = 0; zCount = 0;
        //       load1 = -1; load2 = -1; load3 = -1;
        ownedShots = new int[3] { slot1, slot2, slot3 };
        //Debug.Log(ownedShots);
        playerShot = -1;
        fromCapsule = -1;
        loadCount = 0;

    }

    // Update is called once per frame
    void Update()
    {
        Debug.Log(ownedShots[0] + " " + ownedShots[1] + " " + ownedShots[2]);

        //Debug.Log(xCount + " " + yCount + " " + zCount);

        UpdateShot();
        UpdateOwnedShots();
        FireShot();

        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            BetaLoad();
        }

    }

    void FireShot()
    {
        if (Input.GetKeyDown(KeyCode.Space) && playerShot != -1)
        {
            Instantiate(playerBullet, shotBox.transform.position, shotBox.transform.rotation);
            toCapsule = playerShot;
            Debug.Log("Bang! " + toCapsule);
            ResetShot();
        }

        else if (Input.GetKeyDown(KeyCode.Mouse0) && playerShot == -1)
        {
            Debug.Log("Can't Fire! " + playerShot);

        }

    }

    void UpdateShot()
    {
        if (Input.GetKeyDown(KeyCode.Z) && ownedShots[0] != -1)
        {
            LockAndLoad(ref slot1);
        }
        if (Input.GetKeyDown(KeyCode.X) && ownedShots[1] != -1)
        {
            LockAndLoad(ref slot2);
        }
        if (Input.GetKeyDown(KeyCode.C) && ownedShots[2] != -1)
        {
            LockAndLoad(ref slot3);
        }

        UpdateOwnedShots();
    }

    void LockAndLoad(ref int shot)
    {
        loadCount++;
        int load = -1;
        Debug.Log(loadCount);

        if (loadCount > 0 && loadCount <= 3)
        {
            load = shot;
            shot = -1;

            CheckEm(load);

            GetShotType(xCount, yCount, zCount);
        }

        if (loadCount > 3)
        {
            ResetShot();
        }
    }

    /*    void LockAndLoad(ref int shot)
        {
            loadCount++;
            Debug.Log(loadCount);

            if (loadCount == 1)
            {
                load1 = shot;
                Debug.Log("Load1: " + load1);
                Debug.Log("Load Count: " + loadCount + " PlayerShot: " + playerShot);
            }

            if (loadCount == 2)
            {
                load2 = shot;
                Debug.Log("Load2: " + load2);

                CheckEm(load1, load2, load3);

                GetShotType(xCount, yCount, zCount);
            }

            if (loadCount == 3)
            {
                load3 = shot;
                Debug.Log("Load3: " + load3);

                CheckEm(load1, load2, load3);

                GetShotType(xCount, yCount, zCount);
            }

            if (loadCount > 3)
            {
                ResetShot();
            }
        }*/

    /*    void CheckEm(int l1, int l2, int l3)
        {
            xCount = 0; yCount = 0; zCount = 0;

            int[] loadList = new int[3] { l1, l2, l3 };

            foreach (int i in loadList)
            {
                if(i == 0)
                {
                    xCount++;
                    Debug.Log("xcount: " + xCount);
                }

                if (i == 1)
                {
                    yCount++;
                    Debug.Log("ycount: " + yCount);
                }

                if (i == 2)
                {
                    zCount++;
                    Debug.Log("zcount: " + zCount);
                }
            }
        } */

    void CheckEm(int shotType)
    {
        switch (shotType)
        {
            case (0):
                xCount++;
                break;
            case (1):
                yCount++;
                break;
            case (2):
                zCount++;
                break;
            default:
                Debug.Log("Not a valid shot type from boss: " + shotType);
                break;
        }
    }

    void GetShotType(int xC, int yC, int zC)
    {
        switch (xC)
        {
            case (0):
                switch (yC)
                {
                    case (0):
                        switch (zC)
                        {
                            case (0):
                                Debug.Log("Somthing is up, x,y,z count are all 0!");
                                break;
                            case (1):
                                playerShot = -1;
                                break;
                            case (2):
                                playerShot = (int)ShotType.zz;
                                break;
                            case (3):
                                playerShot = (int)ShotType.zzz;
                                break;
                            default:
                                Debug.Log("Switch zC Used SPLASH: Nothing happened");
                                break;
                        }
                        break;
                    case (1):
                        switch (zC)
                        {
                            case (0):
                                playerShot = -1;
                                break;
                            case (1):
                                playerShot = (int)ShotType.yz;
                                break;
                            case (2):
                                playerShot = (int)ShotType.zzy;
                                break;
                            default:
                                Debug.Log("Switch zC Used SPLASH: Nothing happened");
                                break;
                        }
                        break;
                    case (2):
                        switch (zC)
                        {
                            case (0):
                                playerShot = (int)ShotType.yy;
                                break;
                            case (1):
                                playerShot = (int)ShotType.yyz;
                                break;
                            default:
                                Debug.Log("Switch zC Used SPLASH: Nothing happened");
                                break;
                        }
                        break;
                    case (3):
                        switch (zC)
                        {
                            case (0):
                                playerShot = (int)ShotType.yyy;
                                break;
                        }
                        break;
                    default:
                        Debug.Log("Switch yC Used SPLASH: Nothing happened");
                        break;
                }
                break;
            case (1):
                switch (yC)
                {
                    case (0):
                        switch (zC)
                        {
                            case (0):
                                playerShot = -1;
                                break;
                            case (1):
                                playerShot = (int)ShotType.xz;
                                break;
                            case (2):
                                playerShot = (int)ShotType.zzx;
                                break;
                            default:
                                Debug.Log("Switch zC Used SPLASH: Nothing happened");
                                break;
                        }
                        break;
                    case (1):
                        switch (zC)
                        {
                            case (0):
                                playerShot = (int)ShotType.xy;
                                break;
                            case (1):
                                playerShot = (int)ShotType.xyz;
                                break;
                            default:
                                Debug.Log("Switch zC Used SPLASH: Nothing happened");
                                break;
                        }
                        break;
                    case (2):
                        switch (zC)
                        {
                            case (0):
                                playerShot = (int)ShotType.yyx;
                                break;
                            default:
                                Debug.Log("Switch zC Used SPLASH: Nothing happened");
                                break;
                        }
                        break;
                    default:
                        Debug.Log("Switch yC Used SPLASH: Nothing happened");
                        break;
                }
                break;
            case (2):
                switch (yC)
                {
                    case (0):
                        switch (zC)
                        {
                            case (0):
                                playerShot = (int)ShotType.xx;
                                break;
                            case (1):
                                playerShot = (int)ShotType.xxz;
                                break;
                            default:
                                Debug.Log("Switch zC Used SPLASH: Nothing happened");
                                break;
                        }
                        break;
                    case (1):
                        switch (zC)
                        {
                            case (0):
                                playerShot = (int)ShotType.xxy;
                                break;
                            default:
                                Debug.Log("Switch zC Used SPLASH: Nothing happened");
                                break;
                        }
                        break;
                    default:
                        Debug.Log("Switch yC Used SPLASH: Nothing happened");
                        break;
                }
                break;
            case (3):
                switch (yC)
                {
                    case (0):
                        switch (zC)
                        {
                            case (0):
                                playerShot = (int)ShotType.xxx;
                                break;
                            default:
                                Debug.Log("Switch zC Used SPLASH: Nothing happened");
                                break;
                        }
                        break;
                    default:
                        Debug.Log("Switch yC Used SPLASH: Nothing happened");
                        break;
                }
                break;
            default:
                Debug.Log("Switch xC Used SPLASH: Nothing happened");
                break;
        }
        Debug.Log("Hello from GetShotType: " + playerShot);
    }

    void BetaLoad()
    {
        Slot1 = (int)ShotType.x;
        Slot2 = (int)ShotType.y;
        Slot3 = (int)ShotType.z;
        UpdateOwnedShots();
    }

    void UpdateOwnedShots()
    {
        ownedShots[0] = Slot1;
        ownedShots[1] = Slot2;
        ownedShots[2] = Slot3;
    }

    void ResetShot()
    {
        //       load1 = -1;
        //       load2 = -1;
        //       load3 = -1;
        playerShot = -1;
        loadCount = 0;
        xCount = 0;
        yCount = 0;
        zCount = 0;
    }

    public int Slot1
    {
        get { return slot1; }
        set { slot1 = value; }
    }

    public int Slot2
    {
        get { return slot2; }
        set { slot2 = value; }
    }

    public int Slot3
    {
        get { return slot3; }
        set { slot3 = value; }
    }

    public int PlayerShot
    {
        get { return playerShot; }
        set { playerShot = value; }
    }

    public int ToCapsule
    {
        get { return toCapsule; }
        set { toCapsule = value; }
    }

   void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.tag == "ShotX" || col.gameObject.tag == "ShotY" || col.gameObject.tag == "ShotZ")
        {
            
            //if (player.GameObject.isShielding())
            //bool testShield = player.GetComponent<Player>().isShielding();
            
            DataCapsule capsule = col.collider.GetComponent<DataCapsule>();
            fromCapsule = capsule.Type;
            Debug.Log("I got hit by a:" + fromCapsule + " " + "fromCapsule = " + fromCapsule);
            if (player.GetComponent<Player>().isShielding())
            {
                AbsorbShot();
            }
            else
            {
                player.GetComponent<Player>().takeDamage();
            }
            Destroy(col.gameObject);
        }
    } 

    public void AbsorbShot()
    {
        for (int i = 0; i < ownedShots.Length; i++)
        {
            if (slot1 == -1)
            {
                slot1 = fromCapsule;
                Debug.Log("Asorbed into slot: " + slot1 + " : " + fromCapsule);
                break;
            }

            if (slot2 == -1)
            {
                slot2 = fromCapsule;
                Debug.Log("Asorbed into slot: " + slot2 + " : " + fromCapsule);
                break;
            }

            if (slot3 == -1)
            {
                slot3 = fromCapsule;
                Debug.Log("Asorbed into slot: " + slot3 + " : " + fromCapsule);
                break;
            }
            // Over-Asorb Code
            
            clearShots();
            player.GetComponent<Player>().takeDamage();

        }

        
       
    }
     // Eric's new function: ClearShots()
    void clearShots()
    {
        Debug.Log("OverABSORB");
        slot1 = -1;
        slot2 = -1;
        slot3 = -1;
    }
}
