﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour
{

    GameObject playa;
    BulletManager bManage;

    private float currentDistance;
    public float targetDistance;

    public int currentHealth;
    public int maxHealth;
    private bool invincible;

    public static GameObject currentTarget;
    private GameObject reticule;

    public float moveSpeed;
    public static bool targeting;
    private Vector3 dodgeTarget;
    public float dodgeDist;

    private bool strafing;
    private bool dodging;
    public float dodgeSpeed;
    private bool shielding;

    private bool dead;
    private bool returning;

    //Movement Booleans
    private bool rightDodge;
    private bool leftDodge;
    private bool shield;
    private bool frontStep;
    private bool rightStrafe;
    private bool leftStrafe;
    


    private Vector3 position;

    private float startTime;
    private float dist;
    Vector3 moveDirection;


    // Use this for initialization
    void Awake()
    {
        bManage = gameObject.GetComponent<BulletManager>();
        playa = gameObject;
        moveSpeed = 13.9f;
        targetDistance = 12;
        dodgeDist = 0.75f;
        currentTarget = GameObject.FindWithTag("Target");
        reticule = GameObject.FindWithTag("Reticule");
        maxHealth = 3;
        currentHealth = maxHealth;

        position = new Vector3(playa.transform.position.x, .77f, playa.transform.position.z);

        if (currentTarget) // Enables 3D movement if player has no target selected.
        {
            //targeting = false;
        }

        returning = false;
    }

    void Update()
    {
        rightDodge = Input.GetKeyDown(KeyCode.RightArrow);
        leftDodge = Input.GetKeyDown(KeyCode.LeftArrow);
        shield = Input.GetKeyDown(KeyCode.DownArrow);
        frontStep = Input.GetKeyDown(KeyCode.UpArrow);
        leftStrafe = Input.GetKeyDown(KeyCode.A);
        rightStrafe = Input.GetKeyDown(KeyCode.D);

        if (currentHealth <= 0)
        {
            dead = true;
        }


        if (currentTarget && dead == false)
        {
            if (strafing)
            {
                strafe();
            }
            else if (dodging)
            {
                dodge();
            }
            else
            {
                if (returning == false)
                {
                    UpdateInput();
                }
                updatePosit();
                //updateDistance();

            }
            faceTarget();
        }
    }

    void updatePosit()
    {
        playa.transform.position = Vector3.MoveTowards(transform.position, position, 4 * Time.deltaTime);
        if (transform.position == position)
        {
            returning = false;
        }
    }

    void strafe()
    {
        playa.transform.position = Vector3.MoveTowards(transform.position, dodgeTarget, dodgeSpeed * Time.deltaTime);
        if (playa.transform.position == dodgeTarget)
        {
            strafing = false;
            position.x = playa.transform.position.x;
            position.z = playa.transform.position.z;
        }
    }

    public Vector3 getPlayerPosition()
    {
        return position;
    }

    public void takeDamage()
    {
        StartCoroutine(getHurt());
    }
    IEnumerator getHurt()
    {
        if (invincible)
        {

        }
        else
        {
            Debug.Log("Hurt");
            currentHealth -= 1;
            invincible = true;
        }

        yield return new WaitForSeconds(.5f);
        invincible = false;
    }


    void updateDistance()   // Currently unused
    {
        currentDistance = Vector3.Distance(transform.position, reticule.transform.position);
        if (currentDistance < targetDistance - 0.5)
        {
            playa.transform.Translate(Vector3.back * moveSpeed * Time.deltaTime, Space.Self);
        }
        if (currentDistance > targetDistance + 0.5)
        {
            playa.transform.Translate(Vector3.forward * moveSpeed * Time.deltaTime, Space.Self);
        }
    }

    IEnumerator useShield()
    {
        Debug.Log("START");
        shielding = true;
        yield return new WaitForSeconds(.5f);
        shielding = false;
        Debug.Log("END");
    }


    void UpdateInput()
    {
        if (shield)  // Shield Input
        {          
            StartCoroutine(useShield());
           
        }

        if (!shielding) // Can perform these actions as long as the shield is DOWN
        {
            if (frontStep)
            {
                dodgeTarget = transform.position + (transform.forward * dodgeDist);
                startTime = Time.time;
                dodging = true;
                dist = Vector3.Distance(transform.position, dodgeTarget);
            }
            if (leftDodge)
            {
                dodgeTarget = transform.position - (transform.right * dodgeDist);
                startTime = Time.time;
                dodging = true;
                dist = Vector3.Distance(transform.position, dodgeTarget);
            }
            if (rightDodge)
            {
                dodgeTarget = transform.position + (transform.right * dodgeDist);
                startTime = Time.time;
                dodging = true;
                dist = Vector3.Distance(transform.position, dodgeTarget);
            }
            if (rightStrafe)
            {
                dodgeTarget = reticule.transform.position - (reticule.transform.right * targetDistance);
                strafing = true;

            }
            if (leftStrafe)
            {
                dodgeTarget = reticule.transform.position + (reticule.transform.right * targetDistance);
                strafing = true;

            }
        }

    }

    void dodge()
    {
        float covered = (Time.time - startTime) * 10;
        float fracJourney = covered / dist;
        transform.position = Vector3.Lerp(transform.position, dodgeTarget, fracJourney);
        if (transform.position == dodgeTarget)
        {
            dodging = false;
            returning = true;
        }
    }

    public bool shootable()
    {
        Debug.Log("----- ACESSING VALUE -----");
        bool canShoot = true;
        if (dodging || returning || strafing || shielding)
        {
            canShoot = false;
        }

        return canShoot;
    }
    public bool isShielding()
    {
        return shielding;
    }

    void faceTarget()
    {
        Vector3 targetPosition = reticule.transform.position;
        playa.transform.LookAt(targetPosition);
    }

    public static Vector3 getCurrentTarget()
    {
        Vector3 tPos = new Vector3(currentTarget.transform.position.x, currentTarget.transform.position.y, currentTarget.transform.position.z);
        return tPos;
    }

}
