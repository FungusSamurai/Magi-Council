﻿using UnityEngine;
using System.Collections;

public class Shoot : MonoBehaviour {

    /*public Rigidbody shot1;
    public Rigidbody shot2;
    public Rigidbody shot3;
    public Rigidbody shot4;

    public bool[] ownedShots;
    public bool[] loadedShots;
    private int shotCount;

    //enum ShotCraft { shotType1 = 2, shotType2 = 3, shotType3 = 4, shotType4 = 5, shotType5 = 6, shotType6 = 7, shotType7 = 9};
    enum ShotCraft {shotType1 = 2, shotType2, shotType3};

    public float speed;
 //   private GameObject player;


	// Use this for initialization
	void Awake () {
        speed = 10.0f;
        ownedShots = new bool[3] {true, true, true};
        loadedShots = new bool[3] {false,false,false};
  //      player = GameObject.FindWithTag("Player");
        shotCount = 0;
	
	}
	
	// Update is called once per frame
	void Update () {
        updateShot();
        fireShot();
	
	}

    void updateShot()
    {
        if (Input.GetButtonDown("Load1"))
        {
            manipulateShot(0);
        }
        if (Input.GetButtonDown("Load2"))
        {
            manipulateShot(1);
        }
        if (Input.GetButtonDown("Load3"))
        {
            manipulateShot(2);
        }
    }

    void manipulateShot(int index)
    {
        if (ownedShots[index])
        {
            if (loadedShots[index])
            {
                Debug.Log("Shot " + (index + 1) + " UNloaded");
                loadedShots[index] = false;
                shotCount -= 1;

            }
            else
            {
                Debug.Log("Shot " + (index + 1) + " Loaded");
                shotCount += 1;
                loadedShots[index] = true;
            }
        }
        else
        {
            Debug.Log("Shot Type " + (index + 1) + " is empty");
        }

    }

    void fireShot()
    {
        if (Input.GetButtonDown("Fire"))
        {
            int shotNum = canShoot();
            Debug.Log(shotNum);
            
            switch (shotNum)
            {
                case 5:
                    Instantiate(shot1, transform.position, transform.rotation);
                    clearShot();
                    break;
                case 6:
                    Instantiate(shot2, transform.position, transform.rotation);
                    clearShot();
                    break;
                case 7:
                    Instantiate(shot3, transform.position, transform.rotation);
                    clearShot();
                    break;
                case 9:
                    Instantiate(shot4, transform.position, transform.rotation);
                    clearShot();
                    break;

                default:
                    Debug.Log("CANNOT FIRE");
                    break;

            }
        }
    }

    void clearShot()
    {
        shotCount = 0;
        for (int i = 0; i <= 2; i++)
        {
            if (loadedShots[i])
            {
                loadedShots[i] = false;
                //ownedShots[i] = false;
            }
        }
    }

    int canShoot()
    {
        if (shotCount >= 2)
        {
            int shotID = getShotID(); // Remove this function call once ENUM is completed by Brandon
            return shotID;
        }
        else
        {
            return 0;
        }
    }

    // Remove this function once Brandon finished ENUM
    int getShotID()
    {
        int value = 0;
        for (int i = 0; i <= 2; i++)
        {
            if (loadedShots[i])
            {
                value += i + 2;
            }
        }

        return value;
                
    }*/
}
