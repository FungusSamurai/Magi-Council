﻿using UnityEngine;
using System.Collections;


public class LockToPlayer : MonoBehaviour {

    private GameObject player;

	// Use this for initialization
	void Awake () {
        player = GameObject.FindWithTag("Player");
        facePlayer();
	
	}
	
	// Update is called once per frame
	void Update () {

        facePlayer();
	
	}


    void facePlayer()
    {
        Vector3 targetPosition = player.GetComponent<Player>().getPlayerPosition();
        transform.LookAt(targetPosition);
    }
}
